<!DOCTYPE html>
<html>
<body>
 <a> <a href="Dis.html"> < </a>    Januari 2016    <a href="Feb.html"> > </a> </a>
<table border="1" style="width:30%">
  

   
<tr>
   <center><td style="color:blue;">Su</td></center>
   <center><td style="color:blue;">Mo</td></center>	
   <center><td style="color:blue;">Tu</td></center>
   <center><td style="color:blue;">We</td></center>
   <center><td style="color:blue;">Th</td></center>
   <center><td style="color:blue;">Fr</td></center>
   <center><td style="color:blue;">Sa</td></center>
  </tr>
  <tr>
   <center><td style="color:grey;">27</td></center>
   <center><td style="color:grey;">28</td></center>
   <center><td style="color:grey;">29</td></center>
   <center><td style="color:grey;">30</td></center>
   <center><td style="color:grey;">31</td></center>
   <center><td style="color:red;"><a    href="event.php">1</a></td></center>
   <center><td style="color:red;"><a    href="event2.php">2</a></td></center>
  </tr>
  <tr>
    <center><td style="color:red;">3</td></center>
    <center><td style="color:red;">4</td></center>
    <center><td style="color:red;">5</td></center>
    <center><td style="color:red;">6</td></center>
    <center><td style="color:red;">7</td></center>
    <center><td style="color:red;">8</td></center>
    <center><td style="color:red;">9</td></center>
  </tr>
<tr>
    <center><td style="color:red;">10</td></center>
    <center><td style="color:red;">11</td></center>
    <center><td style="color:red;">12</td></center>
    <center><td style="color:red;">13</td></center>
    <center><td style="color:red;">14</td></center>
    <center><td style="color:red;">15</td></center>
    <center><td style="color:red;">16</td></center>
  </tr>
<tr>
    <center><td style="color:red;">17</td></center>
    <center><td style="color:red;">18</td></center>
    <center><td style="color:red;">19</td></center>
    <center><td style="color:red;">20</td></center>
    <center><td style="color:red;">21</td></center>
    <center><td style="color:red;">22</td></center>
    <center><td style="color:red;">23</td></center>
  </tr>
<tr>
    <center><td style="color:red;">24</td></center>
    <center><td style="color:red;">25</td></center>	
    <center><td style="color:red;">26</td></center>
    <center><td style="color:red;">27</td></center>
    <center><td style="color:red;">28</td></center>
    <center><td style="color:red;">29</td></center>
    <center><td style="color:red;">30</td></center>
  </tr>
<tr>
    <center><td style="color:red;">31</td></center>
    <center><td style="color:grey;">1</td></center>
    <center><td style="color:grey;">2</td></center>
    <center><td style="color:grey;">3</td></center>
    <center><td style="color:grey;">4</td></center>
    <center><td style="color:grey;">5</td></center>
    <center><td style="color:grey;">6</td></center>
  </tr>
</table>

</body>
</html>

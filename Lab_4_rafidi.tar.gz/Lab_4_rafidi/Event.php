<!DOCTYPE html>
<html>
<body>

<h1> Event on 1 January 2016 </h1>

<ul>
   <li>SIM3103 Lab assignment deadline</li>
   <li>SIM3101 Test 1</li>
</il>

<br></br> <form action="Quiz.php" method="post"><input type="text" comment="comment" style="width:50%" style="lenght:50%"><br> <input type="submit">

</form>
</body>
</html>	
